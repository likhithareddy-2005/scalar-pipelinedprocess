first compile the code with the command g++ .\main.cpp
then use (./a.out or ./a.exe) .\input\ICache.txt .\input\DCache.txt .\input\RF.txt  to execute the code
